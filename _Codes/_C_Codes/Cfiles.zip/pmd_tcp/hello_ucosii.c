#include <stdio.h>
#include "includes.h"

/* Nichestack definitions */
#include "ipport.h"
#include "libport.h"
#include "osport.h"
#include "nptcp.h"
#include "socket.h"
#include "tcpport.h"

#define TASK_STACKSIZE 2048

OS_STK init_task_stack[TASK_STACKSIZE];
OS_STK pmd_task_stack[TASK_STACKSIZE];

TK_OBJECT(server_task_to);
TK_ENTRY(server_task);

// This is the data structure used to queue data between the TCP thread and the PMD thread
OS_EVENT* pmd_queue;
char pmd_queue_data[256];

int conn_fd = -1;

typedef struct {
	INT16U start;
	INT16U ready;
	INT16U done;
	INT16U reserved_0;
	INT16U integration_time_lo;
	INT16U integration_time_hi;
	INT16U phase_step;
	INT16U modulation_code_length;
	INT16U modulation_code[16];
} PMDRegs;

void set_integration_time(volatile PMDRegs* regs, INT32U integration_time) {
	regs->integration_time_lo = integration_time & 0x00FFFF;
	regs->integration_time_hi = (integration_time >> 16) & 0x00FFFF;
}

INT32U get_integration_time(volatile PMDRegs* regs) {
	INT32U integration_time = regs->integration_time_lo;
	integration_time |= ((INT32U)regs->integration_time_hi << 16);
	return integration_time;
}

const char VAR_FRAME = 0;
const char VAR_INTEGRATION_TIME = 1;
const char VAR_MODULATION_MODE = 2;
const char VAR_PHASE_STEP = 3;
const char VAR_MODULATION_CODE = 4;

struct inet_taskinfo server_task_info = {
		&server_task_to,
		"PMD server",
		server_task,
		4,
		APP_STACK_SIZE,
};

void init_task(void* args) {
  printf("Initializing...\n");

  // Initialize NicheStack TCP/IP library
  alt_iniche_init();
  netmain();

  // Wait for the library to finish initialization and to acquire IP address
  while (!iniche_net_ready)
    TK_SLEEP(1);

  printf("TCP/IP stack initialized.\n");

  TK_NEWTASK(&server_task_info);

  // Delete this thread, no longer needed
  OSTaskDel(OS_PRIO_SELF);
  while(1);
}

void handle_accept(int, int*);
void handle_receive();

void server_task(void* args) {
	printf("Started PMD server.\n");
	int fd_listen, max_socket;
	struct sockaddr_in addr;
	fd_set read_fds;

	if ((fd_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		printf("Socket creation failed.\n");
	}
	addr.sin_family = AF_INET;
	addr.sin_port = htons(30);
	addr.sin_addr.s_addr = INADDR_ANY;

	if ((bind(fd_listen, (struct sockaddr*)&addr, sizeof(addr))) < 0) {
		printf("Failed to bind to port.\n");
	}

	if ((listen(fd_listen, 1)) < 0) {
		printf("Failed to listen for incoming connections.\n");
	}

	printf("PMD server listening on port %d\n", 30);

	while(1) {
		FD_ZERO(&read_fds);
		FD_SET(fd_listen, &read_fds);
		max_socket = fd_listen+1;

		if (conn_fd != -1) {
			FD_SET(conn_fd, &read_fds);
			if (max_socket <= conn_fd) {
				max_socket = conn_fd + 1;
			}
		}

		select(max_socket, &read_fds, NULL, NULL, NULL);

		if (FD_ISSET(fd_listen, &read_fds)) {
			handle_accept(fd_listen, &conn_fd);
		} else {
			if ((conn_fd != -1) && FD_ISSET(conn_fd, &read_fds)){
				handle_receive();
			}
		}
	}
}

void handle_accept(int fd_listen, int* p_conn_fd) {
	int socket, len;
	struct sockaddr_in incoming_addr;

	len = sizeof(incoming_addr);

	if ((socket = accept(fd_listen, (struct sockaddr*)&incoming_addr, &len)) < 0) {
		printf("Accept failed.\n");
	}
	else {
		*p_conn_fd = socket;
		printf("Accepted connection from %s\n", inet_ntoa(incoming_addr.sin_addr));
	}
}

void handle_receive() {
	char rx_buffer[255];
	int i;
	int count = recv(conn_fd, rx_buffer, 255, 0);
	rx_buffer[254] = '\0';
	for (i = 0; i < count; i++) {
		OSQPost(pmd_queue, (void*)(unsigned)rx_buffer[i]);
	}
}

// Retrieves an 8-bit value from a queue
INT8U next_int8u(OS_EVENT* queue, INT8U* err) {
	void* data = OSQPend(queue, 0, err);
	return (INT8U)(unsigned)data;
}

// Retrieves a 16-bit value from a queue
INT16U next_int16u(OS_EVENT* queue, INT8U* err) {
	INT16U b0 = next_int8u(queue, err);
	INT16U b1 = next_int8u(queue, err);
	return (b1 << 8) | b0;
}

// Retrieves a 32-bit value from a queue
INT32U next_int32u(OS_EVENT* queue, INT8U* err) {
	INT32U w0 = next_int16u(queue, err);
	INT32U w1 = next_int16u(queue, err);
	return (w1 << 16) | w0;
}

void pmd_task(void* args) {
	volatile PMDRegs* pmd_regs = (PMDRegs*)PMD_BASE;
	volatile INT16U* pmd_mem = (INT16U*)(PMD_BASE + 0x8000*2);
	set_integration_time(pmd_regs, 100000*1);
	printf("Integration time: %lu\n", get_integration_time(pmd_regs));

	pmd_regs->modulation_code_length = 31;
	pmd_regs->modulation_code[15] = 0x5d8f;
	pmd_regs->modulation_code[14] = 0x9a42;

	// Square wave, period is 2, first two bits of code are 1 and 0
//	pmd_regs->modulation_code_length = 2;
//	pmd_regs->modulation_code[15] = 0x8000;

	printf("Code length: %d\n", pmd_regs->modulation_code_length);
	printf("Mod[15] is: %04x\n", pmd_regs->modulation_code[15]);
	printf("Mod[14] is: %04x\n", pmd_regs->modulation_code[14]);


	INT8U err;

	while (1) {
		// Wait until ready
		while (!pmd_regs->ready);
		INT8U err;
		INT8U command = next_int8u(pmd_queue, &err);
		INT8U variable = next_int8u(pmd_queue, &err);

		if (command == 'R' && variable == VAR_FRAME) {
			// Begin frame readout
			// Start acquisition
			pmd_regs->start = 1;
			// Wait until done
			while (pmd_regs->done == 0);
			// Readout frame from memory over ethernet
			send(conn_fd, (char*)pmd_mem, 19440*2, 0);
		}
		if (command == 'W' && variable == VAR_PHASE_STEP) {
			INT32U phase_steps = next_int32u(pmd_queue, &err);
			int i;
			for (i = 0; i < phase_steps; i++) {
				pmd_regs->phase_step = 1; // Increment phase by one
				pmd_regs->ready = 1; // This is a no-op essentially, to add a slight delay
			}
			//printf("Phase increased by %lu steps.\n", phase_steps);
		}
		if (command == 'W' && variable == VAR_INTEGRATION_TIME) {
		    set_integration_time(pmd_regs, next_int32u(pmd_queue, &err));
		    printf("Integration time changed to: %lu\n", get_integration_time(pmd_regs));
		}
//		if (command == 'W' && variable == VAR_MODULATION_CODE) {
//			int i;
////			pmd_regs->modulation_code_length = next_int16u(queue, &err);
//			for (i = 15; i >= 0; i--) {
//				pmd_regs->modulation_code[i] = next_int16u(queue, &err);
//			}
//			printf("Modulation code changed, length is now %d\n", pmd_regs->modulation_code_length);
//		}
	}
}

/* The main function creates two task and starts multi-tasking */
int main(void)
{
  INT8U error = 0;
  OSTimeSet(0);

  pmd_queue = OSQCreate((void**)pmd_queue_data, 256);

  // Creates a task to initialize the network and the PMD.
  // This must be done in a separate task instead of the main function,
  // to ensure that the the OS has been started and device drivers are available.
  error = OSTaskCreateExt(init_task, // function pointer
     NULL, // no arguments
     (void*)&init_task_stack[TASK_STACKSIZE], // pointer to top of stack
     5, // priority
     5,
     init_task_stack,
     TASK_STACKSIZE,
     NULL,
     0);

  if (error) {
    printf("Error occurred while creating initial task.");
  }

  error = OSTaskCreate(pmd_task, // function pointer
       NULL, // no arguments
       (void*)&pmd_task_stack[TASK_STACKSIZE], // pointer to top of stack
       6 // priority
       );

  OSStart();
  while(1);

  return 0;
}
