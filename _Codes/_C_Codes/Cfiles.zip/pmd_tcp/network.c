#define IPADDR0   0
#define IPADDR1   0
#define IPADDR2   0
#define IPADDR3   0

#define GWADDR0   0
#define GWADDR1   0
#define GWADDR2   0
#define GWADDR3   0

#define MSKADDR0  255
#define MSKADDR1  255
#define MSKADDR2  255
#define MSKADDR3  0

#include <alt_iniche_dev.h>
#include "ipport.h"
#include "tcpport.h"

#define IP4_ADDR(ipaddr, a,b,c,d) ipaddr = \
    htonl((((alt_u32)(a & 0xff) << 24) | ((alt_u32)(b & 0xff) << 16) | \
          ((alt_u32)(c & 0xff) << 8) | (alt_u32)(d & 0xff)))


// This function is needed by the iniche library.
// Current implementation is a hard-codded MAC address
int get_mac_addr(NET net, unsigned char mac_addr[6])
{
    error_t error = 0;
    mac_addr[0] = 0x00;
    mac_addr[1] = 0x07;
    mac_addr[2] = 0xed;

    /* Reserverd Board identifier */
    mac_addr[3] = 0xFF;
    mac_addr[4] = 0x01;
    mac_addr[5] = 0x02;
    return error;
}

// This function is needed by the iniche library.
// Fetch IP over DHCP
int get_ip_addr(alt_iniche_dev *p_dev,
                ip_addr* ipaddr,
                ip_addr* netmask,
                ip_addr* gw,
                int* use_dhcp)
{

    IP4_ADDR(*ipaddr, IPADDR0, IPADDR1, IPADDR2, IPADDR3);
    IP4_ADDR(*gw, GWADDR0, GWADDR1, GWADDR2, GWADDR3);
    IP4_ADDR(*netmask, MSKADDR0, MSKADDR1, MSKADDR2, MSKADDR3);

#ifdef DHCP_CLIENT
    *use_dhcp = 1;
#else /* not DHCP_CLIENT */
    *use_dhcp = 0;

    printf("Static IP Address is %d.%d.%d.%d\n",
        ip4_addr1(*ipaddr),
        ip4_addr2(*ipaddr),
        ip4_addr3(*ipaddr),
        ip4_addr4(*ipaddr));
#endif /* not DHCP_CLIENT */

    /* Non-standard API: return 1 for success */
    return 1;
}
